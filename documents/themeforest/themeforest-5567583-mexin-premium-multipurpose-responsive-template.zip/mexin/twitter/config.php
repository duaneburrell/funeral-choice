<?php

 $TConfig = array(
	'access_token' => "X",
	'access_token_secret'  => "X",
	'consumer_key'  => "X",
	'consumer_secret' => "X",

	'screen_name'       => 'webnus',
	'count'             => 1
);
?>